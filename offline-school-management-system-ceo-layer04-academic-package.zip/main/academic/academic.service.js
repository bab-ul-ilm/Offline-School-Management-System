const { getDb } = require('../../db/database');

function listAcademicStructure(academicYearId) {
  const db = getDb();
  const year = db.prepare('SELECT id,name,start_date AS startDate,end_date AS endDate,is_current AS isCurrent FROM academic_years WHERE id=?').get(academicYearId);
  if (!year) throw new Error('Academic year not found.');
  const classes = db.prepare(`SELECT c.id,c.name,c.code,c.sort_order AS sortOrder,c.is_active AS isActive,
      COUNT(DISTINCT s.id) AS sectionCount,
      COUNT(DISTINCT csa.subject_id) AS subjectCount
    FROM classes c
    LEFT JOIN sections s ON s.class_id=c.id AND s.is_active=1
    LEFT JOIN class_subject_assignments csa ON csa.class_id=c.id AND csa.academic_year_id=?
    WHERE c.school_id=(SELECT school_id FROM academic_years WHERE id=?)
    GROUP BY c.id ORDER BY c.sort_order,c.name`).all(academicYearId,academicYearId);
  return {year,classes};
}

function listClassSubjects(classId, academicYearId) {
  return getDb().prepare(`SELECT s.id,s.name,s.code,s.subject_type AS subjectType,
      a.weekly_periods AS weeklyPeriods,a.is_compulsory AS isCompulsory
    FROM class_subject_assignments a JOIN subjects s ON s.id=a.subject_id
    WHERE a.class_id=? AND a.academic_year_id=? ORDER BY s.name`).all(classId,academicYearId);
}

function assignSubject(classId, subjectId, academicYearId, weeklyPeriods=1, compulsory=true) {
  if (!Number.isInteger(Number(classId)) || !Number.isInteger(Number(subjectId)) || !Number.isInteger(Number(academicYearId))) throw new Error('Invalid academic structure reference.');
  if (Number(weeklyPeriods)<1 || Number(weeklyPeriods)>60) throw new Error('Weekly periods must be between 1 and 60.');
  getDb().prepare(`INSERT INTO class_subject_assignments(class_id,subject_id,academic_year_id,weekly_periods,is_compulsory)
    VALUES(?,?,?,?,?) ON CONFLICT(class_id,subject_id,academic_year_id) DO UPDATE SET weekly_periods=excluded.weekly_periods,is_compulsory=excluded.is_compulsory`)
    .run(Number(classId),Number(subjectId),Number(academicYearId),Number(weeklyPeriods),compulsory?1:0);
}

function removeSubject(classId, subjectId, academicYearId) {
  return getDb().prepare('DELETE FROM class_subject_assignments WHERE class_id=? AND subject_id=? AND academic_year_id=?').run(Number(classId),Number(subjectId),Number(academicYearId)).changes>0;
}

function addTerm(academicYearId,name,startDate=null,endDate=null,sequenceNo=1) {
  const clean=String(name||'').trim(); if(!clean) throw new Error('Term name is required.');
  return Number(getDb().prepare('INSERT INTO academic_terms(academic_year_id,name,start_date,end_date,sequence_no) VALUES(?,?,?,?,?)').run(Number(academicYearId),clean,startDate||null,endDate||null,Number(sequenceNo)||1).lastInsertRowid);
}

function listTerms(academicYearId) {
  return getDb().prepare('SELECT id,name,start_date AS startDate,end_date AS endDate,sequence_no AS sequenceNo,is_active AS isActive FROM academic_terms WHERE academic_year_id=? ORDER BY sequence_no,name').all(Number(academicYearId));
}

module.exports={listAcademicStructure,listClassSubjects,assignSubject,removeSubject,addTerm,listTerms};
