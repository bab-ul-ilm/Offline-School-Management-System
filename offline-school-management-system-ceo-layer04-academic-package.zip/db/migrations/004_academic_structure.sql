CREATE TABLE IF NOT EXISTS academic_terms (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  academic_year_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  start_date TEXT,
  end_date TEXT,
  sequence_no INTEGER NOT NULL DEFAULT 1,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
  UNIQUE(academic_year_id,name),
  FOREIGN KEY(academic_year_id) REFERENCES academic_years(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS class_teachers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id INTEGER NOT NULL,
  section_id INTEGER,
  teacher_user_id INTEGER NOT NULL,
  academic_year_id INTEGER NOT NULL,
  is_primary INTEGER NOT NULL DEFAULT 0 CHECK(is_primary IN (0,1)),
  UNIQUE(class_id,section_id,academic_year_id,teacher_user_id),
  FOREIGN KEY(class_id) REFERENCES classes(id) ON DELETE CASCADE,
  FOREIGN KEY(section_id) REFERENCES sections(id) ON DELETE SET NULL,
  FOREIGN KEY(teacher_user_id) REFERENCES users(id) ON DELETE RESTRICT,
  FOREIGN KEY(academic_year_id) REFERENCES academic_years(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS curriculum_units (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  class_id INTEGER NOT NULL,
  subject_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  sequence_no INTEGER NOT NULL DEFAULT 1,
  max_marks REAL,
  pass_marks REAL,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK(is_active IN (0,1)),
  UNIQUE(class_id,subject_id,title),
  FOREIGN KEY(class_id) REFERENCES classes(id) ON DELETE CASCADE,
  FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS class_subject_assignments (
  class_id INTEGER NOT NULL,
  subject_id INTEGER NOT NULL,
  academic_year_id INTEGER NOT NULL,
  weekly_periods INTEGER NOT NULL DEFAULT 1,
  is_compulsory INTEGER NOT NULL DEFAULT 1 CHECK(is_compulsory IN (0,1)),
  PRIMARY KEY(class_id,subject_id,academic_year_id),
  FOREIGN KEY(class_id) REFERENCES classes(id) ON DELETE CASCADE,
  FOREIGN KEY(subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
  FOREIGN KEY(academic_year_id) REFERENCES academic_years(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_curriculum_class_subject ON curriculum_units(class_id,subject_id);
CREATE INDEX IF NOT EXISTS idx_class_teachers_year ON class_teachers(academic_year_id,class_id,section_id);
