# CEO LAYER 04 — ACADEMIC STRUCTURE

## Scope
Academic years → terms → classes → sections → subjects → class/subject assignments → curriculum units → class teacher foundation.

## Implemented in this checkpoint
- Academic terms
- Class/subject assignments per academic year
- Weekly subject periods
- Compulsory/elective subject flag
- Curriculum-unit storage foundation
- Class teacher assignment foundation
- Academic structure query service
- Subject assignment/removal service

## Verification
- SQL schema reviewed for foreign keys, uniqueness and indexes.
- Service API validates academic-year and assignment references.
- No duplicate, temporary, backup or preservation files created.

## Integration gate
This is a clean Layer 04 implementation package. It must be merged into the protected Layer 03 source tree before being called the integrated application checkpoint. The protected Layer 03 archive is not present in the current runtime filesystem, so no false integration claim is made.

## Next gate
Restore/use the protected Layer 03 source tree → integrate migration 004 and service → IPC/UI → runtime test → protect.
