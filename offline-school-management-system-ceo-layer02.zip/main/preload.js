const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('schoolSystem', {
  config: {
    get: () => ipcRenderer.invoke('config:get'),
    save: (config) => ipcRenderer.invoke('config:save', config)
  },
  system: { status: () => ipcRenderer.invoke('system:status') },
  backup: { defaultDirectory: () => ipcRenderer.invoke('backup:default-directory'), create: (destinationPath) => ipcRenderer.invoke('backup:create', destinationPath) },
  audit: { recent: (limit) => ipcRenderer.invoke('audit:recent', limit) }
});
