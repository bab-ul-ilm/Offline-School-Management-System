const { getDb } = require('../../db/database');
const { hashPassword, verifyPassword } = require('./password');
const audit = require('../audit/audit.service');

function createUser({ username, displayName, password, roleName = 'Owner' }) {
  const db = getDb();
  const cleanUsername = String(username || '').trim().toLowerCase();
  if (!/^[a-z0-9._-]{3,64}$/.test(cleanUsername)) throw new Error('Username must contain 3-64 lowercase letters, numbers, dot, underscore or hyphen.');
  const { hash, salt } = hashPassword(password);
  const role = db.prepare('SELECT id FROM roles WHERE name = ?').get(roleName);
  if (!role) throw new Error('Role does not exist.');
  const tx = db.transaction(() => {
    const result = db.prepare('INSERT INTO users(username, display_name, password_hash, password_salt) VALUES (?, ?, ?, ?)').run(cleanUsername, String(displayName || cleanUsername), hash, salt);
    db.prepare('INSERT INTO user_roles(user_id, role_id) VALUES (?, ?)').run(result.lastInsertRowid, role.id);
    audit.record({ userId: result.lastInsertRowid, action: 'USER_CREATED', entityType: 'user', entityId: result.lastInsertRowid, newValue: { username: cleanUsername, role: roleName } });
    return Number(result.lastInsertRowid);
  });
  return tx();
}

function authenticate(username, password) {
  const db = getDb();
  const user = db.prepare(`SELECT id, username, display_name, password_hash, password_salt FROM users WHERE username = ? AND is_active = 1`).get(String(username || '').trim().toLowerCase());
  if (!user || !verifyPassword(String(password || ''), user.password_hash, user.password_salt)) return null;
  const roles = db.prepare(`SELECT r.name FROM roles r JOIN user_roles ur ON ur.role_id = r.id WHERE ur.user_id = ? ORDER BY r.name`).all(user.id).map(r => r.name);
  audit.record({ userId: user.id, action: 'LOGIN_SUCCESS', entityType: 'user', entityId: user.id });
  return { id: user.id, username: user.username, displayName: user.display_name, roles };
}

module.exports = { createUser, authenticate };
