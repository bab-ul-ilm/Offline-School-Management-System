const DEFAULT_CONFIG = {
  school: {
    name: 'Your School Name',
    campus: 'Main Campus',
    logoPath: '',
    address: '',
    phone: '',
    email: '',
    website: '',
    slogan: '',
    principal: '',
    registrationReference: ''
  },
  academic: { currentYear: '', currency: 'PKR', language: 'English' },
  branding: { primary: '#163B65', accent: '#2D7FF9' }
};

function cloneDefaultConfig() {
  return JSON.parse(JSON.stringify(DEFAULT_CONFIG));
}

module.exports = { DEFAULT_CONFIG, cloneDefaultConfig };
