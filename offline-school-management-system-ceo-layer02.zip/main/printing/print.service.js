function schoolHeader(school) {
  const safe = value => String(value || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  return `<header class="document-header"><strong>${safe(school.name)}</strong><span>${safe(school.campus)}</span><small>${safe(school.address)}${school.phone ? ` · ${safe(school.phone)}` : ''}</small></header>`;
}

function documentShell({ title, school, body }) {
  return `<!doctype html><html><head><meta charset="utf-8"><title>${title}</title><style>body{font-family:Arial,sans-serif;margin:40px;color:#172033}.document-header{text-align:center;border-bottom:2px solid #163B65;padding-bottom:16px;margin-bottom:28px}.document-header strong,.document-header span,.document-header small{display:block}.document-header strong{font-size:24px}.document-header span{font-size:14px;margin-top:4px}.document-header small{font-size:11px;margin-top:8px;color:#667085}</style></head><body>${schoolHeader(school)}${body}</body></html>`;
}

module.exports = { schoolHeader, documentShell };
