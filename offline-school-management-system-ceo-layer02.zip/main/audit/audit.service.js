const { getDb } = require('../../db/database');

function record({ userId = null, action, entityType = null, entityId = null, previousValue = null, newValue = null, metadata = null }) {
  if (!action) throw new Error('Audit action is required.');
  getDb().prepare(`
    INSERT INTO audit_logs(user_id, action, entity_type, entity_id, previous_value_json, new_value_json, metadata_json)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(userId, action, entityType, entityId == null ? null : String(entityId), JSON.stringify(previousValue), JSON.stringify(newValue), JSON.stringify(metadata));
}

function recent(limit = 100) {
  const safeLimit = Math.max(1, Math.min(Number(limit) || 100, 500));
  return getDb().prepare(`SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?`).all(safeLimit);
}

module.exports = { record, recent };
