const fs = require('fs');
const path = require('path');
const { app } = require('electron');
const { getDb, getDbPath } = require('../db/database');
const audit = require('./audit/audit.service');

async function createBackup(destinationPath, userId = null) {
  if (!destinationPath) throw new Error('Backup destination is required.');
  const destination = path.resolve(destinationPath);
  if (destination === path.resolve(getDbPath())) throw new Error('Backup destination cannot be the live database.');
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  const db = getDb();
  await db.backup(destination);
  const stat = fs.statSync(destination);
  if (stat.size < 100) throw new Error('Backup verification failed: database file is unexpectedly small.');
  audit.record({ userId, action: 'DATABASE_BACKUP_CREATED', entityType: 'backup', entityId: destination, metadata: { sizeBytes: stat.size } });
  return { path: destination, sizeBytes: stat.size };
}

function defaultBackupDirectory() {
  return path.join(app.getPath('documents'), 'School Management Backups');
}

module.exports = { createBackup, defaultBackupDirectory };
