const { getDb } = require('../db/database');
const audit = require('./audit/audit.service');

function rowsFor(db, sql, ...params) { return db.prepare(sql).all(...params); }
function schoolId(db) { return db.prepare('SELECT id FROM schools ORDER BY id LIMIT 1').get().id; }
function parseSettings(db) {
  const map = {};
  for (const row of db.prepare('SELECT key,value_json FROM settings').all()) {
    try { map[row.key] = JSON.parse(row.value_json); } catch { map[row.key] = null; }
  }
  return map;
}
function getConfiguration() {
  const db = getDb();
  const id = schoolId(db);
  const school = db.prepare('SELECT * FROM schools WHERE id=?').get(id);
  const campuses = rowsFor(db, 'SELECT id,name,code,address,phone,is_active FROM campuses WHERE school_id=? ORDER BY name', id);
  const years = rowsFor(db, 'SELECT id,name,start_date AS startDate,end_date AS endDate,is_current AS isCurrent FROM academic_years WHERE school_id=? ORDER BY start_date DESC,name DESC', id);
  const classes = rowsFor(db, 'SELECT id,name,code,sort_order AS sortOrder,is_active AS isActive FROM classes WHERE school_id=? ORDER BY sort_order,name', id).map(c => ({...c, sections: rowsFor(db, 'SELECT id,name,code,is_active AS isActive FROM sections WHERE class_id=? ORDER BY name', c.id)}));
  const subjects = rowsFor(db, 'SELECT id,name,code,subject_type AS subjectType,is_active AS isActive FROM subjects WHERE school_id=? ORDER BY name', id);
  const settings = parseSettings(db);
  return {
    school: { name: school.name || '', slogan: school.slogan || '', logoPath: school.logo_path || '', address: school.address || '', phone: school.phone || '', email: school.email || '', website: school.website || '', principal: school.principal || '', registrationReference: school.registration_reference || '' },
    campuses, academicYears: years, classes, subjects,
    rules: settings.rules || { grading: 'Percentage + Letter Grade', attendance: 'Present / Absent / Leave / Late', promotion: 'Manual review', currency: 'PKR', language: 'English', numbering: 'STU-{000000}' },
    branding: settings.branding || { primary: '#163B65', accent: '#2D7FF9' },
    customFields: rowsFor(db, 'SELECT id,entity_type AS entityType,field_key AS fieldKey,label,field_type AS fieldType,is_required AS isRequired,is_active AS isActive FROM custom_fields ORDER BY entity_type,label')
  };
}
function saveConfiguration(config, userId = null) {
  const db = getDb(); const id = schoolId(db); const previous = getConfiguration();
  const tx = db.transaction(() => {
    const s = config.school || {};
    if (!String(s.name || '').trim()) throw new Error('School name is required.');
    db.prepare(`UPDATE schools SET name=?,slogan=?,logo_path=?,address=?,phone=?,email=?,website=?,principal=?,registration_reference=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(String(s.name).trim(),s.slogan||'',s.logoPath||'',s.address||'',s.phone||'',s.email||'',s.website||'',s.principal||'',s.registrationReference||'',id);
    const upsert = db.prepare(`INSERT INTO settings(key,value_json,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json,updated_at=CURRENT_TIMESTAMP`);
    upsert.run('rules',JSON.stringify(config.rules||{})); upsert.run('branding',JSON.stringify(config.branding||{}));
    const campuses = config.campuses || []; const existing = new Set(db.prepare('SELECT id FROM campuses WHERE school_id=?').all(id).map(r=>r.id));
    const cu=db.prepare('UPDATE campuses SET name=?,code=?,address=?,phone=?,is_active=? WHERE id=?'); const ci=db.prepare('INSERT INTO campuses(school_id,name,code,address,phone,is_active) VALUES(?,?,?,?,?,?)');
    for (const c of campuses) { if (!String(c.name||'').trim()) continue; if (c.id && existing.has(Number(c.id))) cu.run(String(c.name).trim(),c.code||'',c.address||'',c.phone||'',c.isActive===false?0:1,Number(c.id)); else ci.run(id,String(c.name).trim(),c.code||'',c.address||'',c.phone||'',1); }
    if (campuses.length) db.prepare('UPDATE campuses SET is_active=0 WHERE school_id=? AND id NOT IN ('+campuses.map(()=>'?').join(',')+')').run(id,...campuses.filter(c=>c.id).map(c=>Number(c.id)));
    const years=config.academicYears||[]; const yi=db.prepare('INSERT INTO academic_years(school_id,name,start_date,end_date,is_current) VALUES(?,?,?,?,?)'); const yu=db.prepare('UPDATE academic_years SET name=?,start_date=?,end_date=?,is_current=? WHERE id=?');
    db.prepare('UPDATE academic_years SET is_current=0 WHERE school_id=?').run(id); for(const y of years){ if(!String(y.name||'').trim()) continue; if(y.id) yu.run(String(y.name).trim(),y.startDate||null,y.endDate||null,y.isCurrent?1:0,Number(y.id)); else yi.run(id,String(y.name).trim(),y.startDate||null,y.endDate||null,y.isCurrent?1:0); }
    const ciClass=db.prepare('INSERT INTO classes(school_id,name,code,sort_order,is_active) VALUES(?,?,?,?,1)'); const cuClass=db.prepare('UPDATE classes SET name=?,code=?,sort_order=?,is_active=? WHERE id=?'); const si=db.prepare('INSERT INTO sections(class_id,name,code,is_active) VALUES(?,?,?,1)'); const su=db.prepare('UPDATE sections SET name=?,code=?,is_active=? WHERE id=?');
    for(const c of config.classes||[]){ if(!String(c.name||'').trim()) continue; let classId=c.id; if(classId) cuClass.run(String(c.name).trim(),c.code||'',Number(c.sortOrder)||0,c.isActive===false?0:1,Number(classId)); else classId=ciClass.run(id,String(c.name).trim(),c.code||'',Number(c.sortOrder)||0).lastInsertRowid; for(const sec of c.sections||[]){ if(sec.id) su.run(String(sec.name||'').trim(),sec.code||'',sec.isActive===false?0:1,Number(sec.id)); else if(String(sec.name||'').trim()) si.run(classId,String(sec.name).trim(),sec.code||''); } }
    const subI=db.prepare('INSERT INTO subjects(school_id,name,code,subject_type,is_active) VALUES(?,?,?,?,1)'); const subU=db.prepare('UPDATE subjects SET name=?,code=?,subject_type=?,is_active=? WHERE id=?'); for(const x of config.subjects||[]){ if(!String(x.name||'').trim()) continue; if(x.id) subU.run(String(x.name).trim(),x.code||'',x.subjectType||'Academic',x.isActive===false?0:1,Number(x.id)); else subI.run(id,String(x.name).trim(),x.code||'',x.subjectType||'Academic'); }
    audit.record({userId,action:'SCHOOL_CONFIGURATION_UPDATED',entityType:'school',entityId:id,previousValue:previous,newValue:getConfiguration()});
  }); tx(); return getConfiguration();
}
module.exports={getConfiguration,saveConfiguration};
