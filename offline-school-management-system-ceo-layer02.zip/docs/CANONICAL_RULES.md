# CANONICAL CEO RULES

1. Generic commercial product: school-specific information is configuration/data, not code.
2. Offline-first and $0 core; no paid API or cloud dependency for core operations.
3. One permanent student ID and complete lifetime history.
4. One authoritative copy of every project file.
5. Never create .bak, .old, .copy, .tmp, .temp, .backup or preservation source files.
6. Every layer follows PLAN → BUILD → VERIFY → CLEAN → PROTECT → MOVE FORWARD.
7. Do not move forward with unresolved errors.
8. Preserve completed work and avoid unnecessary rebuilds.
9. One consistent professional UI/UX system across every module.
10. Data entered once must be reusable everywhere.
11. School identity must flow into screens and generated documents.
12. Security, auditability, data quality and recovery are first-class requirements.
