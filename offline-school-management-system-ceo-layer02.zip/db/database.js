const { app } = require('electron');
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

let db;

function getDbPath() {
  const dir = path.join(app.getPath('userData'), 'database');
  fs.mkdirSync(dir, { recursive: true });
  return path.join(dir, 'school.db');
}

function migrate(database) {
  database.exec('CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)');
  const migrationDir = path.join(__dirname, 'migrations');
  const files = fs.readdirSync(migrationDir).filter((name) => /^\d+_.*\.sql$/.test(name)).sort();
  const current = database.prepare('SELECT COALESCE(MAX(version), 0) AS version FROM schema_migrations').get().version;
  for (const file of files) {
    const version = Number(file.match(/^(\d+)/)[1]);
    if (version <= current) continue;
    const sql = fs.readFileSync(path.join(migrationDir, file), 'utf8');
    const tx = database.transaction(() => {
      database.exec(sql);
      database.prepare('INSERT INTO schema_migrations(version) VALUES (?)').run(version);
    });
    tx();
    if (version === 1) seedFoundation(database);
  }
}

function seedFoundation(database) {
  const school = database.prepare('SELECT id FROM schools LIMIT 1').get();
  if (!school) {
    const result = database.prepare(`INSERT INTO schools(name) VALUES (?)`).run('Your School Name');
    database.prepare(`INSERT INTO campuses(school_id, name, code) VALUES (?, ?, ?)`).run(result.lastInsertRowid, 'Main Campus', 'MAIN');
  }
  const roles = [
    ['Owner', 'Full system ownership and configuration'],
    ['Principal', 'School-wide management'],
    ['Administrator', 'Operational administration'],
    ['Teacher', 'Teaching and academic operations'],
    ['Accountant', 'Fees and finance operations']
  ];
  const insert = database.prepare('INSERT OR IGNORE INTO roles(name, description) VALUES (?, ?)');
  const tx = database.transaction(() => roles.forEach(([name, description]) => insert.run(name, description)));
  tx();
}

function getDb() {
  if (!db) {
    db = new Database(getDbPath());
    db.pragma('foreign_keys = ON');
    db.pragma('journal_mode = WAL');
    db.pragma('synchronous = FULL');
    migrate(db);
  }
  return db;
}

function closeDb() {
  if (db) { db.close(); db = undefined; }
}

module.exports = { getDb, getDbPath, closeDb };
