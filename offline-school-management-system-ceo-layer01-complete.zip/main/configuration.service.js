const { getDb } = require('../db/database');
const audit = require('./audit/audit.service');

function getConfiguration() {
  const db = getDb();
  const school = db.prepare('SELECT * FROM schools ORDER BY id LIMIT 1').get();
  const campus = db.prepare('SELECT * FROM campuses WHERE school_id = ? ORDER BY id LIMIT 1').get(school.id);
  const settings = db.prepare('SELECT key, value_json FROM settings').all();
  const settingMap = {};
  for (const row of settings) {
    try { settingMap[row.key] = JSON.parse(row.value_json); } catch { settingMap[row.key] = null; }
  }
  return {
    school: {
      name: school.name, campus: campus?.name || '', logoPath: school.logo_path || '', address: school.address || '',
      phone: school.phone || '', email: school.email || '', website: school.website || '', slogan: school.slogan || '',
      principal: school.principal || '', registrationReference: school.registration_reference || ''
    },
    academic: settingMap.academic || { currentYear: '', currency: 'PKR', language: 'English' },
    branding: settingMap.branding || { primary: '#163B65', accent: '#2D7FF9' }
  };
}

function saveConfiguration(config, userId = null) {
  const db = getDb();
  const school = db.prepare('SELECT * FROM schools ORDER BY id LIMIT 1').get();
  const campus = db.prepare('SELECT * FROM campuses WHERE school_id = ? ORDER BY id LIMIT 1').get(school.id);
  const previous = getConfiguration();
  const tx = db.transaction(() => {
    db.prepare(`UPDATE schools SET name=?, slogan=?, logo_path=?, address=?, phone=?, email=?, website=?, principal=?, registration_reference=?, updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(
      String(config.school?.name || 'Your School Name').trim(), config.school?.slogan || '', config.school?.logoPath || '', config.school?.address || '', config.school?.phone || '', config.school?.email || '', config.school?.website || '', config.school?.principal || '', config.school?.registrationReference || '', school.id
    );
    if (campus) db.prepare('UPDATE campuses SET name=? WHERE id=?').run(String(config.school?.campus || 'Main Campus').trim(), campus.id);
    const upsert = db.prepare(`INSERT INTO settings(key,value_json,updated_at) VALUES(?,?,CURRENT_TIMESTAMP) ON CONFLICT(key) DO UPDATE SET value_json=excluded.value_json, updated_at=CURRENT_TIMESTAMP`);
    upsert.run('academic', JSON.stringify(config.academic || {}));
    upsert.run('branding', JSON.stringify(config.branding || {}));
    audit.record({ userId, action: 'SCHOOL_CONFIGURATION_UPDATED', entityType: 'school', entityId: school.id, previousValue: previous, newValue: getConfiguration() });
  });
  tx();
  return getConfiguration();
}

module.exports = { getConfiguration, saveConfiguration };
