const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('schoolSystem', {
  auth: {
    createUser: (payload) => ipcRenderer.invoke('auth:create-user', payload),
    login: (payload) => ipcRenderer.invoke('auth:login', payload),
    logout: (token) => ipcRenderer.invoke('auth:logout', token),
    users: () => ipcRenderer.invoke('auth:users'),
    rolesPermissions: () => ipcRenderer.invoke('auth:roles-permissions')
  },
  config: {
    get: () => ipcRenderer.invoke('config:get'),
    save: (config) => ipcRenderer.invoke('config:save', config)
  },
  system: { status: () => ipcRenderer.invoke('system:status') },
  backup: { defaultDirectory: () => ipcRenderer.invoke('backup:default-directory'), create: (destinationPath) => ipcRenderer.invoke('backup:create', destinationPath) },
  audit: { recent: (limit) => ipcRenderer.invoke('audit:recent', limit) }
});
