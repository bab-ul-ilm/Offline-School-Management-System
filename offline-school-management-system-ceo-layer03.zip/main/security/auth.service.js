const crypto = require('crypto');
const { getDb } = require('../../db/database');
const { hashPassword, verifyPassword } = require('./password');
const audit = require('../audit/audit.service');

const SESSION_HOURS = 8;
const PERMISSIONS = [
  ['system.admin','Manage users, roles, permissions and system settings'],
  ['school.configure','Manage school identity and configuration'],
  ['students.view','View student records'],
  ['students.manage','Create and manage student records'],
  ['academics.manage','Manage classes, subjects, exams and results'],
  ['attendance.manage','Manage attendance'],
  ['finance.manage','Manage fees and finance'],
  ['reports.view','View and export reports'],
  ['backup.manage','Create and restore backups'],
  ['audit.view','View audit and security logs']
];

function seedPermissions() {
  const db=getDb();
  const insert=db.prepare('INSERT OR IGNORE INTO permissions(permission_key,description) VALUES (?,?)');
  const tx=db.transaction(()=>PERMISSIONS.forEach(p=>insert.run(...p))); tx();
  const owner=db.prepare('SELECT id FROM roles WHERE name=?').get('Owner');
  if(owner){
    const all=db.prepare('SELECT id FROM permissions').all();
    const rp=db.prepare('INSERT OR IGNORE INTO role_permissions(role_id,permission_id) VALUES (?,?)');
    const tx2=db.transaction(()=>all.forEach(p=>rp.run(owner.id,p.id))); tx2();
  }
}

function recordSecurity(userId,eventType,success,details){
  getDb().prepare('INSERT INTO security_events(user_id,event_type,success,details_json) VALUES (?,?,?,?)')
    .run(userId||null,eventType,success?1:0,details?JSON.stringify(details):null);
}

function createUser({username,displayName,password,roleName='Administrator'}){
  const db=getDb(); seedPermissions();
  const cleanUsername=String(username||'').trim().toLowerCase();
  if(!/^[a-z0-9._-]{3,64}$/.test(cleanUsername)) throw new Error('Username must contain 3-64 lowercase letters, numbers, dot, underscore or hyphen.');
  if(String(password||'').length<8) throw new Error('Password must be at least 8 characters.');
  const role=db.prepare('SELECT id FROM roles WHERE name=?').get(roleName);
  if(!role) throw new Error('Role does not exist.');
  const {hash,salt}=hashPassword(password);
  const tx=db.transaction(()=>{
    const result=db.prepare('INSERT INTO users(username,display_name,password_hash,password_salt) VALUES (?,?,?,?)')
      .run(cleanUsername,String(displayName||cleanUsername),hash,salt);
    db.prepare('INSERT INTO user_roles(user_id,role_id) VALUES (?,?)').run(result.lastInsertRowid,role.id);
    audit.record({userId:result.lastInsertRowid,action:'USER_CREATED',entityType:'user',entityId:result.lastInsertRowid,newValue:{username:cleanUsername,role:roleName}});
    recordSecurity(result.lastInsertRowid,'USER_CREATED',true,{username:cleanUsername,role:roleName});
    return Number(result.lastInsertRowid);
  });
  return tx();
}

function authenticate(username,password){
  const db=getDb(); seedPermissions();
  const clean=String(username||'').trim().toLowerCase();
  const user=db.prepare('SELECT id,username,display_name,password_hash,password_salt FROM users WHERE username=? AND is_active=1').get(clean);
  if(!user || !verifyPassword(String(password||''),user.password_hash,user.password_salt)){
    recordSecurity(user?.id,'LOGIN_FAILED',false,{username:clean}); return null;
  }
  const roles=db.prepare('SELECT r.name FROM roles r JOIN user_roles ur ON ur.role_id=r.id WHERE ur.user_id=? ORDER BY r.name').all(user.id).map(r=>r.name);
  const token=crypto.randomBytes(32).toString('hex');
  const tokenHash=crypto.createHash('sha256').update(token).digest('hex');
  const expires=new Date(Date.now()+SESSION_HOURS*3600*1000).toISOString();
  db.prepare('INSERT INTO login_sessions(user_id,session_token_hash,expires_at) VALUES (?,?,?)').run(user.id,tokenHash,expires);
  audit.record({userId:user.id,action:'LOGIN_SUCCESS',entityType:'user',entityId:user.id,newValue:{roles}});
  recordSecurity(user.id,'LOGIN_SUCCESS',true);
  return {id:user.id,username:user.username,displayName:user.display_name,roles,sessionToken:token,expiresAt:expires};
}

function revokeSession(token){
  if(!token)return false;
  const hash=crypto.createHash('sha256').update(token).digest('hex');
  const result=getDb().prepare('UPDATE login_sessions SET revoked_at=CURRENT_TIMESTAMP WHERE session_token_hash=? AND revoked_at IS NULL').run(hash);
  return result.changes>0;
}

function getSession(token){
  if(!token)return null;
  const hash=crypto.createHash('sha256').update(token).digest('hex');
  const row=getDb().prepare(`SELECT s.id,s.user_id,s.expires_at,u.username,u.display_name
    FROM login_sessions s JOIN users u ON u.id=s.user_id
    WHERE s.session_token_hash=? AND s.revoked_at IS NULL AND datetime(s.expires_at)>datetime('now') AND u.is_active=1`).get(hash);
  return row||null;
}

function hasPermission(token,permissionKey){
  const session=getSession(token); if(!session)return false;
  return !!getDb().prepare(`SELECT 1 FROM role_permissions rp JOIN permissions p ON p.id=rp.permission_id
    JOIN user_roles ur ON ur.role_id=rp.role_id WHERE ur.user_id=? AND p.permission_key=? LIMIT 1`).get(session.user_id,permissionKey);
}

function listUsers(){
  return getDb().prepare(`SELECT u.id,u.username,u.display_name,u.is_active,u.created_at,
    COALESCE(GROUP_CONCAT(r.name, ', '),'') roles
    FROM users u LEFT JOIN user_roles ur ON ur.user_id=u.id LEFT JOIN roles r ON r.id=ur.role_id
    GROUP BY u.id ORDER BY u.username`).all();
}

function listRolesPermissions(){
  seedPermissions();
  const db=getDb();
  return db.prepare(`SELECT r.id role_id,r.name role_name,p.permission_key,p.description,
    EXISTS(SELECT 1 FROM role_permissions rp2 WHERE rp2.role_id=r.id AND rp2.permission_id=p.id) enabled
    FROM roles r CROSS JOIN permissions p ORDER BY r.name,p.permission_key`).all();
}

module.exports={createUser,authenticate,revokeSession,getSession,hasPermission,listUsers,listRolesPermissions,seedPermissions};
