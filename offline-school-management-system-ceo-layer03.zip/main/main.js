const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const { getDb, closeDb } = require('../db/database');
const { getConfiguration, saveConfiguration } = require('./configuration.service');
const { createUser, authenticate, revokeSession, listUsers, listRolesPermissions, seedPermissions } = require('./security/auth.service');
const audit = require('./audit/audit.service');
const { createBackup, defaultBackupDirectory } = require('./backup.service');

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: '#F4F7FB',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
}

ipcMain.handle('system:status', () => {
  const db = getDb();
  return { database: 'online', sqliteVersion: db.prepare('SELECT sqlite_version() AS version').get().version, schemaVersion: db.prepare('SELECT COALESCE(MAX(version),0) AS version FROM schema_migrations').get().version };
});
ipcMain.handle('config:get', () => getConfiguration());
ipcMain.handle('config:save', (_event, config) => saveConfiguration(config));
ipcMain.handle('auth:create-user', (_event, payload) => createUser(payload));
ipcMain.handle('auth:login', (_event, payload) => authenticate(payload?.username, payload?.password));
ipcMain.handle('auth:logout', (_event, token) => revokeSession(token));
ipcMain.handle('auth:users', () => listUsers());
ipcMain.handle('auth:roles-permissions', () => listRolesPermissions());
ipcMain.handle('audit:recent', (_event, limit) => audit.recent(limit));
ipcMain.handle('backup:default-directory', () => defaultBackupDirectory());
ipcMain.handle('backup:create', (_event, destinationPath) => createBackup(destinationPath));

app.whenReady().then(() => {
  getDb();
  seedPermissions();
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { closeDb(); if (process.platform !== 'darwin') app.quit(); });
app.on('before-quit', closeDb);
