# Canonical CEO Rules

1. Build once; configure for every school.
2. School-specific information is DATA, not CODE.
3. One Student → One Permanent ID → Complete Lifetime History.
4. One School Configuration → Change Once → Apply Everywhere.
5. Data entered once → reused everywhere.
6. One authoritative file → no duplicates → no temporary source files.
7. Every layer follows PLAN → BUILD → VERIFY → CLEAN → PROTECT → MOVE FORWARD.
8. Never advance with unresolved verification errors.
9. Offline-first core; no required paid API/cloud dependency.
10. Preserve completed work; avoid unnecessary rebuilds.
