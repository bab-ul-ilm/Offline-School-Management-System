const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const fs = require('fs');
const { cloneDefaultConfig } = require('./config');

function dataFile(name) {
  const dir = path.join(app.getPath('userData'), 'data');
  fs.mkdirSync(dir, { recursive: true });
  return path.join(dir, name);
}

function loadConfig() {
  const file = dataFile('school-config.json');
  if (!fs.existsSync(file)) return cloneDefaultConfig();
  try { return { ...cloneDefaultConfig(), ...JSON.parse(fs.readFileSync(file, 'utf8')) }; }
  catch { return cloneDefaultConfig(); }
}

function saveConfig(config) {
  const file = dataFile('school-config.json');
  const temp = `${file}.write`; // transient outside the project source; removed immediately
  fs.writeFileSync(temp, JSON.stringify(config, null, 2), 'utf8');
  fs.renameSync(temp, file);
  return true;
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: '#F4F7FB',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
}

ipcMain.handle('config:get', () => loadConfig());
ipcMain.handle('config:save', (_event, config) => saveConfig(config));

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
