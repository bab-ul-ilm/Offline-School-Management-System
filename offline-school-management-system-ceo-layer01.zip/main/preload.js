const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('schoolSystem', {
  config: {
    get: () => ipcRenderer.invoke('config:get'),
    save: (config) => ipcRenderer.invoke('config:save', config)
  }
});
