let config;
const $ = (id) => document.getElementById(id);

function renderIdentity() {
  const school = config.school;
  $('brandName').textContent = school.name || 'School Management';
  $('brandCampus').textContent = school.campus || 'Main Campus';
  $('schoolIdentity').textContent = `${school.name || 'Your School Name'} · ${school.campus || 'Main Campus'}`;
  $('yearValue').textContent = config.academic.currentYear || '—';
}

function openSetup() {
  $('schoolName').value = config.school.name || '';
  $('campus').value = config.school.campus || '';
  $('address').value = config.school.address || '';
  $('phone').value = config.school.phone || '';
  $('email').value = config.school.email || '';
  $('academicYear').value = config.academic.currentYear || '';
  $('setupDialog').showModal();
}

$('setupBtn').addEventListener('click', openSetup);
$('setupForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  config.school.name = $('schoolName').value.trim();
  config.school.campus = $('campus').value.trim();
  config.school.address = $('address').value.trim();
  config.school.phone = $('phone').value.trim();
  config.school.email = $('email').value.trim();
  config.academic.currentYear = $('academicYear').value.trim();
  await window.schoolSystem.config.save(config);
  renderIdentity();
  $('setupDialog').close();
});

(async () => {
  config = await window.schoolSystem.config.get();
  renderIdentity();
})();
